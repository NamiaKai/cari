<?php
require_once(ELP_DIR.'classes'.DIRECTORY_SEPARATOR.'common.php');
require_once(ELP_DIR.'classes'.DIRECTORY_SEPARATOR.'sendmail.php');
require_once(ELP_DIR.'query'.DIRECTORY_SEPARATOR.'dbquery1.php');
require_once(ELP_DIR.'query'.DIRECTORY_SEPARATOR.'dbquery2.php');
?>