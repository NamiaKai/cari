function _elp_redirect() {
	window.location = "admin.php?page=elp-settings";
}

function _elp_help() {
	window.open("http://www.gopiplus.com/work/2014/03/28/wordpress-plugin-email-posts-to-subscribers/");
}